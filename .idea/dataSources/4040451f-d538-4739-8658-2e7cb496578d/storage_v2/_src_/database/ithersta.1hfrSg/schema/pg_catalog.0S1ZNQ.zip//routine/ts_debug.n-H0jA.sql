CREATE FUNCTION ts_debug(document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) RETURNS SETOF record
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION ts_debug(TEXT, OUT TEXT, OUT TEXT, OUT TEXT, OUT REGDICTIONARY[], OUT REGDICTIONARY, OUT TEXT[], OUT TEXT[]) IS 'debug function for current text search configuration';

ALTER FUNCTION ts_debug(TEXT, OUT TEXT, OUT TEXT, OUT TEXT, OUT REGDICTIONARY[], OUT REGDICTIONARY, OUT TEXT[], OUT TEXT[]) OWNER TO postgres;

