CREATE FUNCTION round(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION round(NUMERIC) IS 'value rounded to ''scale'' of zero';

ALTER FUNCTION round(NUMERIC) OWNER TO postgres;

