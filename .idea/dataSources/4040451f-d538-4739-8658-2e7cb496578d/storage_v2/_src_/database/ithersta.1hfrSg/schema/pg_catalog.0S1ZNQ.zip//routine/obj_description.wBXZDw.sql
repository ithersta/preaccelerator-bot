CREATE FUNCTION obj_description(oid, name) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION obj_description(OID, name) IS 'get description for object id and catalog name';

ALTER FUNCTION obj_description(OID, name) OWNER TO postgres;

