CREATE FUNCTION ts_debug(config regconfig, document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) RETURNS SETOF record
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION ts_debug(REGCONFIG, TEXT, OUT TEXT, OUT TEXT, OUT TEXT, OUT REGDICTIONARY[], OUT REGDICTIONARY, OUT TEXT[]) IS 'debug function for text search configuration';

ALTER FUNCTION ts_debug(REGCONFIG, TEXT, OUT TEXT, OUT TEXT, OUT TEXT, OUT REGDICTIONARY[], OUT REGDICTIONARY, OUT TEXT[]) OWNER TO postgres;

