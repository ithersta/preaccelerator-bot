CREATE VIEW check_constraints(constraint_catalog, constraint_schema, constraint_name, check_clause) AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier                              AS constraint_catalog,
       rs.nspname::information_schema.sql_identifier                                      AS constraint_schema,
       con.conname::information_schema.sql_identifier                                     AS constraint_name,
       SUBSTRING(PG_GET_CONSTRAINTDEF(con.oid) FROM 7)::information_schema.character_data AS check_clause
FROM pg_constraint con
         LEFT JOIN pg_namespace rs ON rs.oid = con.connamespace
         LEFT JOIN pg_class c ON c.oid = con.conrelid
         LEFT JOIN pg_type t ON t.oid = con.contypid
WHERE PG_HAS_ROLE(COALESCE(c.relowner, t.typowner), 'USAGE'::TEXT)
  AND con.contype = 'c'::"char"
UNION
SELECT CURRENT_DATABASE()::information_schema.sql_identifier                        AS constraint_catalog,
       n.nspname::information_schema.sql_identifier                                 AS constraint_schema,
       (((((n.oid::TEXT || '_'::TEXT) || r.oid::TEXT) || '_'::TEXT) || a.attnum::TEXT) ||
        '_not_null'::TEXT)::information_schema.sql_identifier                       AS constraint_name,
       (a.attname::TEXT || ' IS NOT NULL'::TEXT)::information_schema.character_data AS check_clause
FROM pg_namespace n,
     pg_class r,
     pg_attribute a
WHERE n.oid = r.relnamespace
  AND r.oid = a.attrelid
  AND a.attnum > 0
  AND NOT a.attisdropped
  AND a.attnotnull
  AND (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]))
  AND PG_HAS_ROLE(r.relowner, 'USAGE'::TEXT);

ALTER TABLE check_constraints
    OWNER TO postgres;

GRANT SELECT ON check_constraints TO PUBLIC;

