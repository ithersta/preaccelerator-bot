CREATE FUNCTION pg_relation_size(regclass) RETURNS bigint
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION pg_relation_size(REGCLASS, TEXT) IS 'disk space usage for the main fork of the specified table or index';

ALTER FUNCTION pg_relation_size(REGCLASS, TEXT) OWNER TO postgres;

