CREATE FUNCTION _pg_numeric_precision(typid oid, typmod integer) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

ALTER FUNCTION _pg_numeric_precision(OID, INTEGER) OWNER TO postgres;

