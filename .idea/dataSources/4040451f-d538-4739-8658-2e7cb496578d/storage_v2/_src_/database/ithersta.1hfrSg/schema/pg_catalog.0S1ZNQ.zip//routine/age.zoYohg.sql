CREATE FUNCTION age(timestamp without time zone) RETURNS interval
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION age(TIMESTAMP, TIMESTAMP) IS 'date difference from today preserving months and years';

ALTER FUNCTION age(TIMESTAMP, TIMESTAMP) OWNER TO postgres;

