CREATE FUNCTION _pg_interval_type(typid oid, mod integer) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

ALTER FUNCTION _pg_interval_type(OID, INTEGER) OWNER TO postgres;

