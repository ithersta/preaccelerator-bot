CREATE VIEW pg_views(schemaname, viewname, viewowner, definition) AS
SELECT n.nspname                   AS schemaname,
       c.relname                   AS viewname,
       PG_GET_USERBYID(c.relowner) AS viewowner,
       PG_GET_VIEWDEF(c.oid)       AS definition
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind = 'v'::"char";

ALTER TABLE pg_views
    OWNER TO postgres;

GRANT SELECT ON pg_views TO PUBLIC;

