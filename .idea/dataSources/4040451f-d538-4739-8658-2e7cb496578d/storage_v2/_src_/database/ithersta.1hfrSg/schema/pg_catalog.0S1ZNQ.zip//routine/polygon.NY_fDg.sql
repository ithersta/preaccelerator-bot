CREATE FUNCTION polygon(circle) RETURNS polygon
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION polygon(circle, circle) IS 'convert circle to 12-vertex polygon';

ALTER FUNCTION polygon(circle, circle) OWNER TO postgres;

