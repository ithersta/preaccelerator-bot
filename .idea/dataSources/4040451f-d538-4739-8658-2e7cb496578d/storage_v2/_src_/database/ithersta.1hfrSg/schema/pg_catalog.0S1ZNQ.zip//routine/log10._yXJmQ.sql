CREATE FUNCTION log10(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION log10(NUMERIC) IS 'base 10 logarithm';

ALTER FUNCTION log10(NUMERIC) OWNER TO postgres;

