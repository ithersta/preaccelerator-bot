CREATE FUNCTION "overlaps"(time without time zone, interval, time without time zone, time without time zone) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION "overlaps"(TIME, INTERVAL, TIME, TIME) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIME, INTERVAL, TIME, TIME) OWNER TO postgres;

