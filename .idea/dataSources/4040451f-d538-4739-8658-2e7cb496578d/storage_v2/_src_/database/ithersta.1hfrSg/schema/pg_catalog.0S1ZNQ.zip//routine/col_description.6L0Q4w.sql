CREATE FUNCTION col_description(oid, integer) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION col_description(OID, INTEGER) IS 'get description for table column';

ALTER FUNCTION col_description(OID, INTEGER) OWNER TO postgres;

