CREATE FUNCTION age(timestamp with time zone) RETURNS interval
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION age(TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE) IS 'date difference from today preserving months and years';

ALTER FUNCTION age(TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE) OWNER TO postgres;

