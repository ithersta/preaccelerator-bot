CREATE FUNCTION numeric_pl_pg_lsn(numeric, pg_lsn) RETURNS pg_lsn
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION numeric_pl_pg_lsn(NUMERIC, pg_lsn) IS 'implementation of + operator';

ALTER FUNCTION numeric_pl_pg_lsn(NUMERIC, pg_lsn) OWNER TO postgres;

