CREATE FUNCTION log(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION log(NUMERIC) IS 'base 10 logarithm';

ALTER FUNCTION log(NUMERIC) OWNER TO postgres;

