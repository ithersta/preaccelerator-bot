CREATE VIEW views
            (table_catalog, table_schema, table_name, view_definition, check_option, is_updatable, is_insertable_into,
             is_trigger_updatable, is_trigger_deletable, is_trigger_insertable_into)
AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier AS table_catalog,
       nc.nspname::information_schema.sql_identifier         AS table_schema,
       c.relname::information_schema.sql_identifier          AS table_name,
       CASE
           WHEN PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT) THEN PG_GET_VIEWDEF(c.oid)
           ELSE NULL::TEXT
           END::information_schema.character_data            AS view_definition,
       CASE
           WHEN 'check_option=cascaded'::TEXT = ANY (c.reloptions) THEN 'CASCADED'::TEXT
           WHEN 'check_option=local'::TEXT = ANY (c.reloptions) THEN 'LOCAL'::TEXT
           ELSE 'NONE'::TEXT
           END::information_schema.character_data            AS check_option,
       CASE
           WHEN (pg_relation_is_updatable(c.oid::regclass, FALSE) & 20) = 20 THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                 AS is_updatable,
       CASE
           WHEN (pg_relation_is_updatable(c.oid::regclass, FALSE) & 8) = 8 THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                 AS is_insertable_into,
       CASE
           WHEN (EXISTS(SELECT 1
                        FROM pg_trigger
                        WHERE pg_trigger.tgrelid = c.oid
                          AND (pg_trigger.tgtype::INTEGER & 81) = 81)) THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                 AS is_trigger_updatable,
       CASE
           WHEN (EXISTS(SELECT 1
                        FROM pg_trigger
                        WHERE pg_trigger.tgrelid = c.oid
                          AND (pg_trigger.tgtype::INTEGER & 73) = 73)) THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                 AS is_trigger_deletable,
       CASE
           WHEN (EXISTS(SELECT 1
                        FROM pg_trigger
                        WHERE pg_trigger.tgrelid = c.oid
                          AND (pg_trigger.tgtype::INTEGER & 69) = 69)) THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                 AS is_trigger_insertable_into
FROM pg_namespace nc,
     pg_class c
WHERE c.relnamespace = nc.oid
  AND c.relkind = 'v'::"char"
  AND NOT PG_IS_OTHER_TEMP_SCHEMA(nc.oid)
  AND (PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT) OR
       HAS_TABLE_PRIVILEGE(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
       HAS_ANY_COLUMN_PRIVILEGE(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE views
    OWNER TO postgres;

GRANT SELECT ON views TO PUBLIC;

