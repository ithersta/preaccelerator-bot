CREATE FUNCTION lpad(text, integer) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION lpad(TEXT, INTEGER, TEXT) IS 'left-pad string to length';

ALTER FUNCTION lpad(TEXT, INTEGER, TEXT) OWNER TO postgres;

