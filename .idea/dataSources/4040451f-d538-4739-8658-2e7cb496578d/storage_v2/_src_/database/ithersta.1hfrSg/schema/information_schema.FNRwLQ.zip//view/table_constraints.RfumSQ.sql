CREATE VIEW table_constraints
            (constraint_catalog, constraint_schema, constraint_name, table_catalog, table_schema, table_name,
             constraint_type, is_deferrable, initially_deferred, enforced)
AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier  AS constraint_catalog,
       nc.nspname::information_schema.sql_identifier          AS constraint_schema,
       c.conname::information_schema.sql_identifier           AS constraint_name,
       CURRENT_DATABASE()::information_schema.sql_identifier  AS table_catalog,
       nr.nspname::information_schema.sql_identifier          AS table_schema,
       r.relname::information_schema.sql_identifier           AS table_name,
       CASE c.contype
           WHEN 'c'::"char" THEN 'CHECK'::TEXT
           WHEN 'f'::"char" THEN 'FOREIGN KEY'::TEXT
           WHEN 'p'::"char" THEN 'PRIMARY KEY'::TEXT
           WHEN 'u'::"char" THEN 'UNIQUE'::TEXT
           ELSE NULL::TEXT
           END::information_schema.character_data             AS constraint_type,
       CASE
           WHEN c.condeferrable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                  AS is_deferrable,
       CASE
           WHEN c.condeferred THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.yes_or_no                  AS initially_deferred,
       'YES'::CHARACTER VARYING::information_schema.yes_or_no AS enforced
FROM pg_namespace nc,
     pg_namespace nr,
     pg_constraint c,
     pg_class r
WHERE nc.oid = c.connamespace
  AND nr.oid = r.relnamespace
  AND c.conrelid = r.oid
  AND (c.contype <> ALL (ARRAY ['t'::"char", 'x'::"char"]))
  AND (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]))
  AND NOT PG_IS_OTHER_TEMP_SCHEMA(nr.oid)
  AND (PG_HAS_ROLE(r.relowner, 'USAGE'::TEXT) OR
       HAS_TABLE_PRIVILEGE(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
       HAS_ANY_COLUMN_PRIVILEGE(r.oid, 'INSERT, UPDATE, REFERENCES'::TEXT))
UNION ALL
SELECT CURRENT_DATABASE()::information_schema.sql_identifier         AS constraint_catalog,
       nr.nspname::information_schema.sql_identifier                 AS constraint_schema,
       (((((nr.oid::TEXT || '_'::TEXT) || r.oid::TEXT) || '_'::TEXT) || a.attnum::TEXT) ||
        '_not_null'::TEXT)::information_schema.sql_identifier        AS constraint_name,
       CURRENT_DATABASE()::information_schema.sql_identifier         AS table_catalog,
       nr.nspname::information_schema.sql_identifier                 AS table_schema,
       r.relname::information_schema.sql_identifier                  AS table_name,
       'CHECK'::CHARACTER VARYING::information_schema.character_data AS constraint_type,
       'NO'::CHARACTER VARYING::information_schema.yes_or_no         AS is_deferrable,
       'NO'::CHARACTER VARYING::information_schema.yes_or_no         AS initially_deferred,
       'YES'::CHARACTER VARYING::information_schema.yes_or_no        AS enforced
FROM pg_namespace nr,
     pg_class r,
     pg_attribute a
WHERE nr.oid = r.relnamespace
  AND r.oid = a.attrelid
  AND a.attnotnull
  AND a.attnum > 0
  AND NOT a.attisdropped
  AND (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]))
  AND NOT PG_IS_OTHER_TEMP_SCHEMA(nr.oid)
  AND (PG_HAS_ROLE(r.relowner, 'USAGE'::TEXT) OR
       HAS_TABLE_PRIVILEGE(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
       HAS_ANY_COLUMN_PRIVILEGE(r.oid, 'INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE table_constraints
    OWNER TO postgres;

GRANT SELECT ON table_constraints TO PUBLIC;

