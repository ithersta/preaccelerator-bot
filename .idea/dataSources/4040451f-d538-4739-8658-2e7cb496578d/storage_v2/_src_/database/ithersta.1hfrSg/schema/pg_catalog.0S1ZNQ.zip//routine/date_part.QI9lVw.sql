CREATE FUNCTION date_part(text, date) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION date_part(TEXT, DATE) IS 'extract field from date';

ALTER FUNCTION date_part(TEXT, DATE) OWNER TO postgres;

