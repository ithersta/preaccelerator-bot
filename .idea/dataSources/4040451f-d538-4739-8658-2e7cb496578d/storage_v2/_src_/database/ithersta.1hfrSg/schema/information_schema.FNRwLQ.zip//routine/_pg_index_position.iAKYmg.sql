CREATE FUNCTION _pg_index_position(oid, smallint) RETURNS integer
    STABLE
    STRICT
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

ALTER FUNCTION _pg_index_position(OID, SMALLINT) OWNER TO postgres;

