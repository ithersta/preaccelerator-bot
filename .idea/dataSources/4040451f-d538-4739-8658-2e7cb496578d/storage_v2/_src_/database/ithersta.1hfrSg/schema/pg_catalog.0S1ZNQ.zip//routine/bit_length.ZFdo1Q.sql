CREATE FUNCTION bit_length(text) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION bit_length(TEXT) IS 'length in bits';

ALTER FUNCTION bit_length(TEXT) OWNER TO postgres;

