CREATE FUNCTION substring(text, text, text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION substring(TEXT, TEXT, TEXT) IS 'extract text matching SQL regular expression';

ALTER FUNCTION substring(TEXT, TEXT, TEXT) OWNER TO postgres;

