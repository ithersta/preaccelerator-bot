CREATE FUNCTION xpath(text, xml) RETURNS xml[]
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION xpath(TEXT, xml, TEXT[]) IS 'evaluate XPath expression';

ALTER FUNCTION xpath(TEXT, xml, TEXT[]) OWNER TO postgres;

