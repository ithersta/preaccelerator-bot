CREATE FUNCTION _pg_char_octet_length(typid oid, typmod integer) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

ALTER FUNCTION _pg_char_octet_length(OID, INTEGER) OWNER TO postgres;

