CREATE FUNCTION xpath_exists(text, xml) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION xpath_exists(TEXT, xml, TEXT[]) IS 'test XML value against XPath expression';

ALTER FUNCTION xpath_exists(TEXT, xml, TEXT[]) OWNER TO postgres;

