CREATE FUNCTION shobj_description(oid, name) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION shobj_description(OID, name) IS 'get description for object id and shared catalog name';

ALTER FUNCTION shobj_description(OID, name) OWNER TO postgres;

