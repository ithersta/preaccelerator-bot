CREATE FUNCTION rpad(text, integer) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

COMMENT ON FUNCTION rpad(TEXT, INTEGER, TEXT) IS 'right-pad string to length';

ALTER FUNCTION rpad(TEXT, INTEGER, TEXT) OWNER TO postgres;

