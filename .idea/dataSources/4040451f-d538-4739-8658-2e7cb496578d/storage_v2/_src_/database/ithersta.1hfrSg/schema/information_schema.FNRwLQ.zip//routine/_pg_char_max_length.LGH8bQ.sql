CREATE FUNCTION _pg_char_max_length(typid oid, typmod integer) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

ALTER FUNCTION _pg_char_max_length(OID, INTEGER) OWNER TO postgres;

