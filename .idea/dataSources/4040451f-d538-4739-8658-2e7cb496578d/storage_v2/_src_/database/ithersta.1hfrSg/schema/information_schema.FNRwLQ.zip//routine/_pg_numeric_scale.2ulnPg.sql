CREATE FUNCTION _pg_numeric_scale(typid oid, typmod integer) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
AS
$$
    BEGIN
-- missing source code
END;
$$;

ALTER FUNCTION _pg_numeric_scale(OID, INTEGER) OWNER TO postgres;

